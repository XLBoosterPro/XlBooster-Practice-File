
Smart Masking Demo - Full Installation / Usage Steps (Hindi)

1) File contents in this ZIP:
   - sample_data.xlsx  -> Workbook with example data (sheet "Data")
   - Module_SmartMask.bas -> VBA module (main procedures)
   - Class_clsXLMaskEvent.cls -> VBA class file (event handling)
   - README.txt -> This file

2) How to create a working demo (.xlsm) from these files:
   a) Open Excel (make sure Developer tab is enabled: File -> Options -> Customize Ribbon -> check Developer).
   b) Save a copy of sample_data.xlsx as Macro-Enabled Workbook:
      - File -> Save As -> Excel Macro-Enabled Workbook (*.xlsm) and give a name.
   c) Press ALT+F11 to open the VBA Editor (VBE).
   d) In VBE: File -> Import File... -> select Module_SmartMask.bas and click Open.
   e) Again: File -> Import File... -> select Class_clsXLMaskEvent.cls and click Open.
      - You should now see a Module (with the procedures) and a Class named clsXLMaskEvent in the project tree.
   f) In VBA Editor, ensure "Microsoft Forms 2.0 Object Library" is available:
      - Tools -> References -> check "Microsoft Forms 2.0 Object Library".
   g) Save the workbook (it must be saved as .xlsm).

3) Add a button to run the demo:
   Option 1 (Form Control button):
     - Developer tab -> Insert -> Form Controls -> Button.
     - Draw the button on any sheet.
     - When asked to assign macro, choose "StartSmartMasking" and click OK.
     - Click the button to run the Smart Masking wizard.

   Option 2 (ActiveX Command Button):
     - Developer tab -> Insert -> ActiveX Controls -> Command Button.
     - Right-click the button -> Properties -> change Caption if needed.
     - Right-click -> View Code and call `StartSmartMasking` inside the Click event:
         Private Sub CommandButton1_Click()
             StartSmartMasking
         End Sub

4) ActiveX/Controls security:
   - If ActiveX controls are disabled, the macro will prompt you to enable them.
   - To enable: File -> Options -> Trust Center -> Trust Center Settings -> ActiveX Settings -> Choose "Enable all controls without restrictions..."
   - After changing ActiveX settings you may need to completely close Excel and re-open.

5) Using the demo:
   - Open the .xlsm file with the imported module/class and the sample data.
   - Click the button you added.
   - Select the Data range (include header row).
   - Choose to create a new MaskBoard sheet or pick a destination cell.
   - Use the Masking UI to pick columns and mask types. Click "Export Masked Data" to save masked results.

6) Notes:
   - The provided code references a function `AllowPaidFeature` used to gate functionality. If you don't have this function in your project, you can temporarily comment out or remove the check:
        ' If Not AllowPaidFeature("PDF_SPLITTER") Then Exit Sub
   - If any ActiveX control creation fails, enable ActiveX or use the Form Control button to run StartSmartMasking directly.
   - Dates in the sample are real Excel date types; the engine preserves date values unless a mask is applied.

If you want, I can also:
 - Create a ready .xlsm with the macros pre-imported (requires embedding VBA which I can attempt), or
 - Add a small recorded screencast steps (GIF) showing import steps.
