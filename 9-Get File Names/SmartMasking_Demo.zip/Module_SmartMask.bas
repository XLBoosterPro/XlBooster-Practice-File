
Option Explicit

' Global instance for the Masking Engine
Public GlobalMaskEvent As clsXLMaskEvent

' 1) Entry macro: Callable from a Ribbon button
Public Sub StartSmartMaskingUI(control As IRibbonControl)

        'Converting to Paid Features
    If Not AllowPaidFeature("PDF_SPLITTER") Then Exit Sub

    Call StartSmartMasking
End Sub

Public Sub StartSmartMasking()
    Dim wsData As Worksheet
    Dim rngData As Range
    Dim rngDest As Range
    Dim destCell As Range
    Dim wsDest As Worksheet

    If ActiveWorkbook Is Nothing Then Exit Sub

    ' --- STEP 0: Proactive Beginner-Friendly ActiveX Check ---
    If ActiveSheet.ProtectContents Then
        MsgBox "Your current sheet is protected. Please unprotect it first to use Smart Masking.", vbExclamation, "XLBooster - Sheet Protected"
        Exit Sub
    End If

    If Not CheckAndPromptActiveXMask() Then Exit Sub

    ' --- STEP 1: Select Original Data ---
    On Error Resume Next
    Set rngData = Application.InputBox( _
        prompt:="Please select your Data Range including Headers." & vbCrLf & _
                "First row must be HEADER.", _
        Title:="Smart Masking - Select Data", Type:=8)
    On Error GoTo 0

    If rngData Is Nothing Then Exit Sub
    Set rngData = Intersect(rngData, rngData.Worksheet.usedRange)

    If rngData Is Nothing Or rngData.rows.count < 2 Then
        MsgBox "Invalid selection or range is too small.", vbCritical, "Error"
        Exit Sub
    End If

    ' --- STEP 2: CHOOSE DESTINATION METHOD ---
    Dim userChoice As VbMsgBoxResult
    userChoice = MsgBox("Do you want to create the Smart Masking Board on a brand NEW sheet?" & vbCrLf & vbCrLf & _
                        "• Click [YES] to automatically create it on a New Sheet." & vbCrLf & _
                        "• Click [NO] to manually select a specific cell on an existing sheet.", _
                        vbYesNoCancel + vbQuestion, "Choose Destination - XLBooster")

    If userChoice = vbCancel Then Exit Sub

    If userChoice = vbYes Then
        Application.ScreenUpdating = False
        Set wsDest = Worksheets.Add(After:=rngData.parent)
        wsDest.name = "MaskBoard_" & Format(Now, "hhmmss")
        Set destCell = wsDest.Range("B2")
        Application.ScreenUpdating = True
    Else
        On Error Resume Next
        Set rngDest = Application.InputBox( _
            prompt:="STEP 2: Select a SINGLE CELL where you want to place the Masking Dashboard:", _
            Title:="XLBooster - Select Destination Cell", Default:="", Type:=8)
        On Error GoTo 0

        If rngDest Is Nothing Then Exit Sub
        Set destCell = rngDest.Cells(1, 1)
        Set wsDest = destCell.Worksheet

        If wsDest.name = rngData.parent.name Then
            If Not Intersect(destCell.Resize(rngData.rows.count + 5, rngData.Columns.count), rngData) Is Nothing Then
                MsgBox "WARNING: Your selected destination overlaps with your original data!", vbCritical, "Error"
                Exit Sub
            End If
        End If
    End If

    Call RemoveOldMaskControls(wsDest)
    Application.ScreenUpdating = False

    ' --- STEP 3: ADD LABELS (Row 2) ---
    destCell.EntireRow.RowHeight = 22
    With destCell
        .value = "1. Select Column"
        .Font.Bold = True
        .Font.Size = 11
        .Font.color = RGB(44, 62, 80)
    End With

    With destCell.Offset(0, 3)
        .value = "2. Select Mask Type"
        .Font.Bold = True
        .Font.Size = 11
        .Font.color = RGB(44, 62, 80)
    End With

    ' --- STEP 4: Clone Data (Starting at Row 4) ---
    destCell.Offset(2, 0).Resize(rngData.rows.count + 10, rngData.Columns.count + 2).Clear

    rngData.Copy
    With destCell.Offset(2, 0)
        .PasteSpecial Paste:=xlPasteColumnWidths
        .PasteSpecial Paste:=xlPasteFormats
        .PasteSpecial Paste:=xlPasteValues
    End With
    Application.CutCopyMode = False

    Dim copiedData As Range
    Set copiedData = destCell.Offset(2, 0).Resize(rngData.rows.count, rngData.Columns.count)

    ' --- DATE FIX: Removed `.NumberFormat = "@"` line. Now Excel will respect real Dates! ---

    ' --- STEP 5: Create Controls (Row 3) ---
    Dim ctrlCell As Range
    Set ctrlCell = destCell.Offset(1, 0)
    ctrlCell.EntireRow.RowHeight = 35

    Dim t As Double, L As Double
    t = ctrlCell.Top + 6
    L = ctrlCell.Left + 2

    wsDest.Activate
    Application.ScreenUpdating = True

    Dim objCol As Object, objType As Object, objBtn As Object
    Dim ts As String: ts = Format(Now, "hhmmss")

    Set objCol = wsDest.OLEObjects.Add(ClassType:="Forms.ComboBox.1", Left:=L, Top:=t, width:=150, height:=22)
    objCol.name = "cmbMaskCol_" & ts

    Set objType = wsDest.OLEObjects.Add(ClassType:="Forms.ComboBox.1", Left:=L + 180, Top:=t, width:=180, height:=22)
    objType.name = "cmbMaskType_" & ts

    Set objBtn = wsDest.OLEObjects.Add(ClassType:="Forms.CommandButton.1", Left:=L + 400, Top:=t, width:=150, height:=24)
    objBtn.name = "btnMaskExport_" & ts

    With objBtn.Object
        .caption = "Export Masked Data"
        .backColor = RGB(44, 62, 80)
        .ForeColor = RGB(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 9
        .Font.name = "Segoe UI"
    End With

    ' --- STEP 6: Populate ComboBoxes ---
    Dim cbCol As Object, cbType As Object
    Set cbCol = objCol.Object
    Set cbType = objType.Object

    cbCol.Clear
    cbType.Clear

    Dim c As Long
    For c = 1 To rngData.Columns.count
        cbCol.AddItem Trim(rngData.Cells(1, c).value)
    Next c

    cbType.AddItem "0. None (Original Data)"
    cbType.AddItem "1. Mobile Number (******3210)"
    cbType.AddItem "2. Email ID (jo***@gmail.com)"
    cbType.AddItem "3. Aadhaar Card (XXXX XXXX 1234)"
    cbType.AddItem "4. PAN Card (AB***1234F)"
    cbType.AddItem "5. Credit/Debit Card (XXXX-1234)"
    cbType.AddItem "6. Bank Account (XXXXXXXX1234)"
    cbType.AddItem "7. Date of Birth (XX-XX-YYYY)"
    cbType.AddItem "8. Name Partial (R**** S*****)"
    cbType.AddItem "9. Passport (Z*****67)"
    cbType.AddItem "10. Full Mask (**********)"

    ' --- STEP 7: Connect Engine ---
    Set GlobalMaskEvent = New clsXLMaskEvent
    Set GlobalMaskEvent.MaskColCombo = cbCol
    Set GlobalMaskEvent.MaskTypeCombo = cbType
    Set GlobalMaskEvent.ExportBtn = objBtn.Object

    ' DATE FIX: Used .Value instead of .Value2 to ensure Dates stay Dates in memory
    GlobalMaskEvent.SourceData = rngData.value
    Set GlobalMaskEvent.DestDataRange = copiedData

    Call GlobalMaskEvent.InitMemory

    cbCol.ListIndex = 0
    cbType.ListIndex = 0

    MsgBox "Smart Masking Engine is Ready!" & vbCrLf & vbCrLf & _
           "1. Select a Column." & vbCrLf & _
           "2. Choose a Masking Type (Aadhaar, PAN, Email, etc.)." & vbCrLf & _
           "3. Repeat for other columns!" & vbCrLf & _
           "Click 'Export' when you are done.", vbInformation, "XLBooster - Engine Activated"
    Exit Sub
End Sub

Private Function CheckAndPromptActiveXMask() As Boolean
    Dim testObj As Object
    On Error GoTo ActiveXBlocked
    Application.ScreenUpdating = False
    Set testObj = ActiveSheet.OLEObjects.Add(ClassType:="Forms.TextBox.1", Left:=0, Top:=0, width:=1, height:=1)
    testObj.Delete
    Application.ScreenUpdating = True
    CheckAndPromptActiveXMask = True
    Exit Function
ActiveXBlocked:
    Application.ScreenUpdating = True
    CheckAndPromptActiveXMask = False
    Dim msg As String
    msg = "Welcome to the Smart Masking Tool! ?" & vbCrLf & vbCrLf & _
          "To make this automation work perfectly, it is compulsory to enable a quick Excel setting (ActiveX Controls)." & vbCrLf & vbCrLf & _
          "Would you like to open the settings right now to enable it?" & vbCrLf & _
          "(Note: In the window that opens, click 'ActiveX Settings' on the left side, select 'Enable all controls...', and click OK.)"
    Dim userChoice As VbMsgBoxResult
    userChoice = MsgBox(msg, vbYesNo + vbExclamation, "XLBooster - Quick Setup Required")
    If userChoice = vbYes Then
        On Error Resume Next
        Application.CommandBars.ExecuteMso "MacroSecurity"
        On Error GoTo 0
        MsgBox "Thank you! Please restart Excel completely and try again.", vbInformation, "Restart Required"
    End If
End Function

Private Sub RemoveOldMaskControls(ws As Worksheet)
    Dim shp As Shape
    For Each shp In ws.Shapes
        If shp.Type = msoOLEControlObject Then
            If shp.name Like "cmbMaskCol_*" Or shp.name Like "cmbMaskType_*" Or shp.name Like "btnMaskExport_*" Then
                shp.Delete
            End If
        End If
    Next shp
End Sub
